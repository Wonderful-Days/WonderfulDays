<?php 
$registerName = $_POST['registerName'];
$registerUsername = $_POST['registerUsername'];
$registerEmail = $_POST['registerEmail'];
$registerPassword = $_POST['registerPassword'];
$registerRepeatPassword = $_POST['registerRepeatPassword'];

// Establish database connection
$conn = new mysqli('localhost', 'root', '', 'test');
if($conn->connect_error) {
  die('Connection Failed : ' . $conn->connect_error);
} else {
  // Prepare SQL statement
  $stmt = $conn->prepare("INSERT INTO registration (registerName, registerUsername, registerEmail, registerPassword, registerRepeatPassword) VALUES (?, ?, ?, ?, ?)");
  // Bind parameters
  $stmt->bind_param("sssss", $registerName, $registerUsername, $registerEmail, $registerPassword, $registerRepeatPassword);
  // Execute SQL statement
  $stmt->execute();
  echo "Registration successful.";
  // Close prepared statement and connection
  $stmt->close();
  $conn->close(); 
}
?>
